module.exports = {
    // disbable logging for production
    logging: false,
    db: {
        seed: false,
        url: process.env.DB_URL_PROD,
    }
};