module.exports = {
    // enabled logging for development
    logging: true,
    db: {
        seed: true,
        url: process.env.DB_URL,
    },
};