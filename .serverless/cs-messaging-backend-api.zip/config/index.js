const _ = require('lodash');
require('dotenv').config();

const config = {
    dev: 'development',
    test: 'testing',
    prod: 'production',
    port: process.env.PORT || 3000,
    // 10 days in minutes

    MONGO_URI: process.env.MONGO_URI || 'mongodb://localhost/csMessaging',
};

process.env.NODE_ENV = process.env.NODE_ENV || config.dev;
config.env = process.env.NODE_ENV;

let envConfig;
// falling back to an empty object if require errors out
try {
    envConfig = require(`./${config.env}`);
    envConfig = envConfig || {};
} catch (e) {
    envConfig = {};
}

// merging environment config and module config object
module.exports = _.merge(config, envConfig);